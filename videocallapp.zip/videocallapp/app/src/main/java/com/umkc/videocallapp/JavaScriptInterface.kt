package com.umkc.videocallapp

import android.webkit.JavascriptInterface

class JavaScriptInterface(private val activityVideo: VideoCallActivity) {

    @JavascriptInterface
    public fun onPeerConnected() {
        activityVideo.onPeerConnected()
    }
}