package com.umkc.videocallapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.core.app.ActivityCompat
import com.google.firebase.ktx.Firebase
import com.google.firebase.ktx.initialize

class LoginActivity : AppCompatActivity() {
    private val requestCode = 1
    private val access = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.caller_login)
        if (!isPermissionGranted()) {
            ActivityCompat.requestPermissions(this, access, requestCode)
        }
        Firebase.initialize(this)
        findViewById<Button>(R.id.loginbutton).setOnClickListener {
            val userName = findViewById<EditText>(R.id.username).text.toString()
            val intent = Intent(this, VideoCallActivity::class.java)
            intent.putExtra("username", userName)
            startActivity(intent)
        }
    }
    private fun isPermissionGranted(): Boolean {
        access.forEach {
            if (ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED)
                return false
        }
        return true
    }
}