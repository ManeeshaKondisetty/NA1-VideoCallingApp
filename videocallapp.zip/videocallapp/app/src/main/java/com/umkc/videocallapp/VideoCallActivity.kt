package com.umkc.videocallapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import java.util.*

class VideoCallActivity : AppCompatActivity() {

    var username = ""
    var friendsUsername = ""
    var isPeerConnected = false
    var uniqueId = ""

    var firebaseRef = Firebase.database.getReference("users")

    var isAudio = true
    var isVideo = true

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.view_video_call)

        username = intent.getStringExtra("username")!!

        findViewById<Button>(R.id.call).setOnClickListener {
            friendsUsername = findViewById<EditText>(R.id.callername).text.toString()
            sendCallRequest()
        }

        findViewById<ImageView>(R.id.switchaudio).setOnClickListener {
            isAudio = !isAudio
            callJavaScriptFunction("javascript:toggleAudio(\"$ isAudio\")")
            findViewById<ImageView>(R.id.switchaudio).setImageResource(
                if (isAudio)
                    R.drawable.ic_baseline_mic_24
                else
                    R.drawable.ic_baseline_mic_off_24
            )
        }

        findViewById<ImageView>(R.id.switchvideo).setOnClickListener {
            isVideo = !isVideo
            callJavaScriptFunction("javascript:toggleVideo(\"${isVideo}\")")
            findViewById<ImageView>(R.id.switchvideo).setImageResource(
                if (isVideo)
                    R.drawable.ic_baseline_videocam_24
                else
                    R.drawable.ic_baseline_videocam_off_24
            )
        }

        findViewById<Button>(R.id.end).setOnClickListener {
            finish()
        }
        setupWebView()
    }

    private fun sendCallRequest() {
        if(!isPeerConnected) {
            Toast.makeText(this, "You are not connect, check your internet.", Toast.LENGTH_SHORT).show()
            return
        }
        firebaseRef.child(friendsUsername).child("incoming").setValue(username)
        firebaseRef.child(friendsUsername).child("isAvailable").addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.value.toString() == "true") {
                    listenForConnectionId()
                }
            }
            override fun onCancelled(error: DatabaseError) {
            }
        })
    }

    private fun listenForConnectionId() {
        firebaseRef.child(friendsUsername).child("connId").addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.value == null)
                    return
                findViewById<LinearLayout>(R.id.enterdata).visibility = View.GONE
                findViewById<Button>(R.id.end).visibility = View.VISIBLE
                findViewById<LinearLayout>(R.id.callcontrol).visibility = View.VISIBLE
                val decryptUUID = decryptString(snapshot.value.toString())
                callJavaScriptFunction("javaScript: startCall(\"$decryptUUID\")")
            }
            override fun onCancelled(error: DatabaseError) {
            }

        })
    }

    private fun setupWebView() {
        webView = findViewById(R.id.videocallview)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }
        webView.settings.javaScriptEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.addJavascriptInterface(JavaScriptInterface(this), "Android")
        val filePath = "file:android_asset/call.html"
        webView.loadUrl(filePath)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                uniqueId = UUID.randomUUID().toString()
                callJavaScriptFunction("javascript:init(\"${uniqueId}\")")
                firebaseRef.child(username).child("incoming")
                    .addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            onCallRequest(snapshot.value as? String)
                        }

                        override fun onCancelled(error: DatabaseError) {
                        }

                    })
            }
        }
    }

    private fun onCallRequest(caller: String?) {
        if (caller == null) return
        var calLayout = findViewById<RelativeLayout>(R.id.callwindow)
        calLayout.visibility = View.VISIBLE
        findViewById<TextView>(R.id.incoming).text = "$caller is calling..."
        findViewById<ImageView>(R.id.answer).setOnClickListener {
            val encryptUUID = encryptString(uniqueId)
            // Encrypt
            firebaseRef.child(username).child("connId").setValue(encryptUUID)
            firebaseRef.child(username).child("isAvailable").setValue(true)
            calLayout.visibility = View.GONE
            findViewById<LinearLayout>(R.id.enterdata).visibility = View.GONE
            findViewById<Button>(R.id.end).visibility = View.VISIBLE
            findViewById<LinearLayout>(R.id.callcontrol).visibility = View.VISIBLE
        }

        findViewById<ImageView>(R.id.decline).setOnClickListener {
            firebaseRef.child(username).child("incoming").setValue(null)
            calLayout.visibility = View.GONE
        }
    }

    private fun callJavaScriptFunction(functionString: String) {
        webView.post {
            webView.evaluateJavascript(functionString, null)
        }
    }

    fun onPeerConnected() {
        isPeerConnected = true
    }

    override fun onBackPressed() {
        finish()
    }

    override fun onDestroy() {
        firebaseRef.child(username).setValue(null)
        webView.loadUrl("about:blank")
        super.onDestroy()
    }

    private fun encryptString(clearText: String) : String {
        return AESUtils.encrypt(clearText)
    }

    private fun decryptString(encryptedText: String): String {
        return AESUtils.decrypt(encryptedText)
    }
}